return {
Token = "6130252257:AAHPiv9CsWEDq2csYVpk5-8I6OtOFrEql3o",
UserBot = "whshsjushsusiwu10bot",
UserSudo = "b99b4",
SudoId = 6221975079}
